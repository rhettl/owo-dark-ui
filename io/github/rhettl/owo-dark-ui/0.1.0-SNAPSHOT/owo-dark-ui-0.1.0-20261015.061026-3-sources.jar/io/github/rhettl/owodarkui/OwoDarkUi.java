package io.github.rhettl.owodarkui;

import io.github.rhettl.owodarkui.menu.InventoryOnlyMenu;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

/**
 * Common entrypoint: registers the playground menu on both logical sides.
 * The library adds no commands; consumers open the playground with
 * {@link io.github.rhettl.owodarkui.playground.Playground#open}.
 */
public final class OwoDarkUi implements ModInitializer {
    public static final String MOD_ID = "rhettl-owo-dark-ui";

    public static final class_3917<InventoryOnlyMenu> PLAYGROUND_MENU = class_2378.method_10230(
        class_7923.field_41187, id("playground"),
        new class_3917<>((syncId, inventory) -> new InventoryOnlyMenu(OwoDarkUi.PLAYGROUND_MENU, syncId, inventory),
            class_7701.field_40182));

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        // PLAYGROUND_MENU registers when this class loads.
    }
}
