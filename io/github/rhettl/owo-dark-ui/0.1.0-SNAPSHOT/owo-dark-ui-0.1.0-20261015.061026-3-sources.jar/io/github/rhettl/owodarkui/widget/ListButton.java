package io.github.rhettl.owodarkui.widget;

import io.github.rhettl.owodarkui.theme.Palette;
import io.github.rhettl.owodarkui.theme.Themes;
import io.wispforest.owo.ui.component.ButtonComponent;
import io.wispforest.owo.ui.core.Sizing;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/** A focusable item/text list row with no tooltip, built on owo's real button. */
public final class ListButton extends ButtonComponent {
    public static final int HEIGHT = 20;
    private final class_1799 icon;
    private final boolean evenRow;
    private boolean selected;

    public ListButton(ListWell.Entry entry, int index, Consumer<ListWell.Entry> onPress) {
        super(entry.text(), button -> onPress.accept(entry));
        icon = entry.icon().method_7972();
        evenRow = (index & 1) == 0;
        sizing(Sizing.fill(100), Sizing.fixed(HEIGHT));
        textShadow(false);
    }

    /** Persistent selection; owo's active flag continues to mean enabled. */
    public void selected(boolean selected) {
        this.selected = selected;
    }

    public boolean selected() {
        return selected;
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float delta) {
        var palette = Themes.palette();
        int x = method_46426(), y = method_46427(), width = method_25368(), height = method_25364();
        boolean focused = active() && method_25370();
        boolean hovered = active() && method_49606();
        boolean highlighted = focused || hovered;
        int background = selected ? palette.selected()
            : highlighted ? palette.panel() : evenRow ? palette.frame() : palette.well();
        graphics.method_25294(x, y, x + width, y + height, background);
        if (selected || highlighted) {
            graphics.method_25294(x, y, x + 1, y + height,
                highlighted ? palette.accentHighlight() : palette.accent());
        }

        int textX = x + (icon.method_7960() ? 4 : 2);
        if (!icon.method_7960()) {
            graphics.method_51427(icon, textX, y + (height - 16) / 2);
            textX += 21;
        }
        var font = class_310.method_1551().field_1772;
        int available = Math.max(0, x + width - 2 - textX);
        var message = method_25369();
        int color = !active() ? palette.textMuted()
            : selected || highlighted ? palette.accentHighlight() : palette.textPrimary();
        if (font.method_27525(message) <= available) {
            graphics.method_51439(font, message, textX, y + (height - font.field_2000) / 2, color, false);
        } else {
            String shortened = font.method_27523(message.getString(), Math.max(0, available - font.method_1727("…")));
            graphics.method_51433(font, shortened + "…", textX, y + (height - font.field_2000) / 2, color, false);
        }
    }
}
