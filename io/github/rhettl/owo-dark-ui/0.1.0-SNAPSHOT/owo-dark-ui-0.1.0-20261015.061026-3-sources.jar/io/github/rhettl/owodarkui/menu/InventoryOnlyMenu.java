package io.github.rhettl.owodarkui.menu;

import io.wispforest.owo.client.screens.SlotGenerator;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

/**
 * A menu backed entirely by the player's own inventory, for previews and
 * playgrounds. Register a {@link class_3917} per screen that should use it.
 * Slots 0-26 are the main inventory and 27-35 the hotbar.
 */
public class InventoryOnlyMenu extends class_1703 {
    public static final int INVENTORY_SLOTS = 27;
    public static final int TOTAL_SLOTS = 36;

    public InventoryOnlyMenu(class_3917<?> type, int syncId, class_1661 inventory) {
        super(type, syncId);
        // Client slot components supply the final layout coordinates.
        SlotGenerator.begin(this::method_7621, 0, 0).playerInventory(inventory);
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        if (index < 0 || index >= TOTAL_SLOTS) return class_1799.field_8037;
        var slot = method_7611(index);
        if (!slot.method_7681()) return class_1799.field_8037;
        var stack = slot.method_7677();
        var original = stack.method_7972();
        boolean moved = index < INVENTORY_SLOTS
            ? method_7616(stack, INVENTORY_SLOTS, TOTAL_SLOTS, false)
            : method_7616(stack, 0, INVENTORY_SLOTS, false);
        if (!moved) return class_1799.field_8037;
        if (stack.method_7960()) slot.method_53512(class_1799.field_8037);
        else slot.method_7668();
        slot.method_7667(player, stack);
        return original;
    }
}
