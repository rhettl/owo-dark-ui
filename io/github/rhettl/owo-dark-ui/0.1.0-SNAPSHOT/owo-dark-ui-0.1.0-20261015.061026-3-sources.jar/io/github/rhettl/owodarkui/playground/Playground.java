package io.github.rhettl.owodarkui.playground;

import io.github.rhettl.owodarkui.OwoDarkUi;
import io.github.rhettl.owodarkui.menu.InventoryOnlyMenu;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/** Server-side entry point for the component playground. */
public final class Playground {
    private Playground() {}

    /** Opens the playground for this player; the title is shown in the playground header. */
    public static void open(class_3222 player, class_2561 title) {
        player.method_17355(new class_747(
            (syncId, inventory, owner) -> new InventoryOnlyMenu(OwoDarkUi.PLAYGROUND_MENU, syncId, inventory),
            title));
    }
}
