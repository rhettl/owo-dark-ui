package io.github.rhettl.owodarkui.playground.tabs;

import io.github.rhettl.owodarkui.playground.PlaygroundTab;
import io.github.rhettl.owodarkui.widget.ListWell;
import io.wispforest.owo.ui.component.Components;
import io.wispforest.owo.ui.component.LabelComponent;
import io.wispforest.owo.ui.container.Containers;
import io.wispforest.owo.ui.container.FlowLayout;
import io.wispforest.owo.ui.core.HorizontalAlignment;
import io.wispforest.owo.ui.core.Sizing;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

/** Short and scrolling item/text lists with no list-item tooltips. */
public final class ListWellTab implements PlaygroundTab {
    private LabelComponent selection;

    @Override public String tabName() { return "List Well"; }

    @Override
    public FlowLayout getContent() {
        var content = Containers.verticalFlow(Sizing.fill(100), Sizing.content());
        content.gap(6);
        selection = Components.label(class_2561.method_43470("Select a row with click, Enter, or Space.")
            .method_27692(class_124.field_1080)).shadow(false);
        selection.horizontalSizing(Sizing.fill(100));
        var examples = Containers.horizontalFlow(Sizing.fill(100), Sizing.content());
        examples.gap(8);

        var shortList = List.of(
            new ListWell.Entry(class_1799.field_8037, class_2561.method_43470("All items")),
            new ListWell.Entry(new class_1799(class_1802.field_20391), class_2561.method_43470("Materials")),
            new ListWell.Entry(new class_1799(class_1802.field_8403), class_2561.method_43470("Tools")));
        examples.child(example("SHORT LIST", shortList, false));

        var items = List.of(class_1802.field_20391, class_1802.field_8583, class_1802.field_8620, class_1802.field_8695,
            class_1802.field_8687, class_1802.field_8477, class_1802.field_8371, class_1802.field_8403,
            class_1802.field_8229, class_1802.field_8279, class_1802.field_8745, class_1802.field_8529);
        var entries = items.stream().map(ListWellTab::entry).toList();
        examples.child(example("SCROLLING LIST", entries, true));
        content.child(examples);
        content.child(selection);

        var hint = Components.label(class_2561.method_43470("Item icons and text, including a text-only row. Scroll inside the right well. No item tooltips.")
            .method_27692(class_124.field_1080)).shadow(false);
        hint.horizontalSizing(Sizing.fill(100));
        hint.horizontalTextAlignment(HorizontalAlignment.CENTER);
        content.child(hint);
        return content;
    }

    private FlowLayout example(String title, List<ListWell.Entry> entries, boolean scrollable) {
        var column = Containers.verticalFlow(Sizing.expand(50), Sizing.content());
        column.gap(5);
        column.child(Components.label(class_2561.method_43470(title).method_27692(class_124.field_1065)).shadow(false));
        column.child(ListWell.create(Sizing.fill(100), entries, 5, scrollable,
            entry -> selection.text(class_2561.method_43470("Selected: ").method_10852(entry.text()))));
        return column;
    }

    private static ListWell.Entry entry(class_1792 item) {
        var stack = new class_1799(item);
        return new ListWell.Entry(stack, stack.method_7964());
    }
}
