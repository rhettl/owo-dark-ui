package io.github.rhettl.owodarkui.widget;

import io.github.rhettl.owodarkui.theme.Palette;
import io.github.rhettl.owodarkui.theme.Themes;
import io.wispforest.owo.ui.component.ButtonComponent;
import io.wispforest.owo.ui.component.Components;
import io.wispforest.owo.ui.core.OwoUIDrawContext;
import io.wispforest.owo.ui.core.Sizing;
import io.wispforest.owo.ui.core.Surface;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

/** Focusable folder tabs and their connection to a frame. */
public final class Tabs {
    private Tabs() {}

    public enum State { ACTIVE, INACTIVE, DISABLED }

    /** A stateful text tab. The parent owns selection and supplies the click action. */
    public static ButtonComponent tab(String label, State state, Runnable onPress) {
        var tab = Components.button(class_2561.method_43470(label), button -> onPress.run());
        int width = Math.max(82, class_310.method_1551().field_1772.method_1727(label) + 24);
        tab.sizing(Sizing.fixed(width), Sizing.fixed(22));
        tab.textShadow(false);
        state(tab, state);
        return tab;
    }

    /** Update in place so selection changes retain keyboard focus. */
    public static void state(ButtonComponent tab, State state) {
        tab.active(state != State.DISABLED);
        var label = class_2561.method_43470(tab.method_25369().getString());
        tab.method_25355(state == State.DISABLED
            ? label.method_27695(class_124.field_1080, class_124.field_1055)
            : label.method_27692(state == State.ACTIVE ? class_124.field_1065 : class_124.field_1068));
        tab.renderer((context, button, delta) -> {
            boolean hovered = button.method_25367();
            drawTab(context, button.method_46426(), button.method_46427(), button.method_25368(), button.method_25364(),
                state, hovered);
        });
    }

    /** Join the selected tab to this dark frame by opening only its top border. */
    public static void dock(Frames.Frame frame, Supplier<ButtonComponent> selectedTab) {
        Surface original = frame.outer().surface();
        frame.outer().surface((context, component) -> {
            original.draw(context, component);
            var tab = selectedTab.get();
            if (tab == null || tab.method_46427() + tab.method_25364() != component.y()) return;
            int left = Math.max(component.x() + 3, tab.method_46426());
            int right = Math.min(component.x() + component.width() - 3, tab.method_46426() + tab.method_25368());
            if (right - left < 4) return;
            var palette = Themes.palette();
            context.method_25294(left + 2, component.y(), right - 2, component.y() + 3, palette.frame());
            context.method_25294(left, component.y(), left + 1, component.y() + 3, palette.edgeShadow());
            context.method_25294(left + 1, component.y(), left + 2, component.y() + 3, palette.border());
            context.method_25294(right - 2, component.y(), right, component.y() + 3, palette.edgeShadow());
        });
    }

    private static void drawTab(OwoUIDrawContext context, int x, int y, int width, int height,
                                State state, boolean hovered) {
        Palette palette = Themes.palette();
        boolean selected = state == State.ACTIVE;
        boolean enabled = state != State.DISABLED;
        int top = y + (selected ? 0 : 3);
        int bottom = y + height;
        int body = selected ? palette.frame()
            : enabled && hovered ? palette.panel() : palette.well();
        int bevel = selected ? palette.border()
            : enabled && hovered ? palette.textMuted() : palette.edgeMid();
        int topBevel = selected
            ? hovered ? palette.accentHighlight() : palette.accent()
            : bevel;
        // Four-pixel rounded upper corners, drawn in logical pixels to stay crisp at every GUI scale.
        for (int row = 0; row < 4; row++) {
            int inset = switch (row) {
                case 0 -> 4;
                case 1 -> 2;
                case 2 -> 1;
                default -> 0;
            };
            context.method_25294(x + inset, top + row, x + width - inset, top + row + 1, palette.edgeShadow());
            if (row == 0) continue;
            context.method_25294(x + inset + 1, top + row, x + width - inset - 2, top + row + 1,
                row == 1 ? topBevel : body);
            if (row > 1) {
                context.method_25294(x + inset + 1, top + row, x + inset + 2, top + row + 1, bevel);
            }
        }
        context.method_25294(x, top + 4, x + width, bottom, palette.edgeShadow());
        context.method_25294(x + 1, top + 4, x + width - 2, bottom, body);
        context.method_25294(x + 1, top + 4, x + 2, bottom, bevel);
        if (!selected) context.method_25294(x + 2, bottom - 1, x + width - 2, bottom, palette.edgeShadow());
    }
}
